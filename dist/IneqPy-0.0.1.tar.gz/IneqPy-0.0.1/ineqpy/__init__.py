'''
IneqPy


'''

from .ineqpy import *

__author__ = "Maximiliano Greco"
__version__ = "0.0.1"
__maintainer__ = "Maximiliano Greco"
__email__ = "mmngreco@gmail.com"
__status__ = "Production"

print("IneqPy: A PYTHON PACKAGE TO QUANTITATIVE ANALYSIS OF INEQUALITY LODADED")